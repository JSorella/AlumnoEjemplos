﻿namespace AlumnoEjemplos.LosBorbotones
{
    public interface Renderizable
    {
        void render();
    }
}
