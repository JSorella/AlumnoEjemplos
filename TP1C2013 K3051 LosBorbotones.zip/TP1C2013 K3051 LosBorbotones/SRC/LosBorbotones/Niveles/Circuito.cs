﻿
namespace AlumnoEjemplos.LosBorbotones.Niveles
{
    interface Circuito : Renderizable
    {
        string getNombre();
       
    }
}
